package training.service;

public interface HelloService {
	
	public void sayHello(String name);
	
}
