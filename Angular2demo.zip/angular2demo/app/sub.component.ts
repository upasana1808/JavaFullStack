import {Component} from "@angular/core";

@Component({
   selector: 'sub-app',
   template: '<h2>Sub component</h2>'
})


export class SubComponent {

}